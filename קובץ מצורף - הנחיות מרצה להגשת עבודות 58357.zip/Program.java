
public class Program {

	public static void main(String[] args) {
		
		DrivingGame game=new DrivingGame(10, 5);
		game.play();

	}

}
